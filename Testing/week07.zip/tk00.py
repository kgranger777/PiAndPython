# tk00.py
# "your first tkinter program"
# showing the very basics of using tkinter with Python
import tkinter as Tk
root = Tk.Tk()
root.title("My Window")
root.mainloop()
